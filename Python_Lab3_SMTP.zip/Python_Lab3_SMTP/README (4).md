# Python Lab 3 — SMTP Mail Client

**Student:** Nisha Patel  
**Course:** Advanced Computer Networks (MSCS-631)  
**Language:** Python 3

## Overview

This project implements a simple SMTP mail client using Python socket programming. The client connects to Gmail, authenticates, sends an email, and closes the connection through a visible SMTP command-and-response exchange. It does not use `smtplib`.

The implementation extends the supplied lab skeleton with TLS and authentication for Gmail. It uses `EHLO`, the extended form of `HELO`, to support authenticated SMTP submission.

## Project Files

| File | Purpose |
| --- | --- |
| `smtp_client.py` | Complete socket-based SMTP client |
| `Lab3_Reflection_Nisha_Patel.docx` | Two-paragraph reflection with in-text citations and references |
| `screenshots/SS1_Received_Email.png` | Required screenshot showing the received email |
| `README.md` | Project description, setup, execution, and submission guidance |

## Requirements

- Python 3 installed on your computer.
- Internet access and an outbound connection to `smtp.gmail.com` on TCP port `465`.
- A Gmail account that permits app passwords, with 2-Step Verification enabled.
- A Google app password created for the sending account.
- A recipient email address. Sending to your own Gmail address is acceptable for this lab.

All imported modules are part of Python’s standard library. No `pip install` command is needed.

## Account Setup

1. Sign in to the Gmail account you intend to use as the sender.
2. Open [Google Account security settings](https://myaccount.google.com/security) and enable 2-Step Verification if needed.
3. Open [Google App Passwords](https://myaccount.google.com/apppasswords).
4. Create an app password named **Python SMTP Lab**.
5. Use the generated password when the client asks for the Gmail app password.

App passwords may be unavailable for some managed accounts or account security configurations. If unavailable, consult your instructor about an approved SMTP server; this client is configured specifically for Gmail.

Keep the app password private. Do not save it in the source code, README, screenshots, or submitted ZIP.

## Run on Windows

1. Extract the project ZIP.
2. Open the extracted folder containing `smtp_client.py`.
3. Click the File Explorer address bar, type `cmd`, and press **Enter**.
4. Run:

   ```text
   py smtp_client.py
   ```

   If the Python launcher is unavailable, try:

   ```text
   python smtp_client.py
   ```

5. Enter the sender Gmail address at `Your Gmail address:`.
6. Enter the destination address at `Recipient email address:`. You may use the sender address again.
7. Paste the sender account’s app password at `Gmail app password (hidden):` and press **Enter**. No characters appear while entering the password.
8. Review the terminal output, then open the recipient mailbox to verify receipt.

## SMTP Sequence

| Stage | Client action | Expected response |
| --- | --- | --- |
| Connection | Establish TCP connection and certificate-verified TLS | `220` greeting |
| Introduction | `EHLO localhost` | `250` capabilities |
| Authentication | `AUTH LOGIN` and encoded credentials over TLS | `334` prompts, followed by `235` |
| Sender | `MAIL FROM:<sender>` | `250` |
| Recipient | `RCPT TO:<recipient>` | `250` or `251` |
| Message request | `DATA` | `354` |
| Message transfer | Send headers and body, ending with a period on its own line | `250` |
| Session closure | `QUIT` | `221` |

The client reads complete multiline SMTP replies, checks response codes, applies a socket timeout, and uses `sendall()` to transmit data. Credentials are not printed in the terminal. Base64 encodes authentication fields; TLS provides encryption for the connection.

## Email Content

**Subject:** Python Lab 3 SMTP Test - Nisha Patel

**Body:**

```text
I love computer networks!

This email was sent using my Python socket-based SMTP client for Python Lab 3.
```

The message includes From, To, Subject, Date, Message-ID, and content headers. A blank line separates the headers from the body, and the SMTP end-of-data marker terminates the message.

## Observed Test Results

The successful terminal run showed:

- `235 2.7.0 Accepted` after authentication.
- `250` responses for the sender and recipient.
- `354 Go ahead` after `DATA`.
- `250 2.0.0 OK` after the completed message.
- `221 2.0.0 closing connection` after `QUIT`.

These responses confirm authentication, server acceptance of the message, and normal session closure. The received-email screenshot provides the separate evidence of arrival required by the assignment.

Earlier runs returned `535` for rejected credentials and `534` stating that an application-specific password was required. Using the sender account’s Google app password resolved authentication and allowed the SMTP exchange to finish successfully.

## Screenshot Evidence

### Required — Received Email

Open the received message and capture its subject, sender, recipient, date or time, and message body. Save the image as:

```text
screenshots/SS1_Received_Email.png
```

If needed, expand the sender and recipient details in Gmail before taking the screenshot. Check Spam or All Mail if the message is not visible in the Inbox.


## Troubleshooting

| Problem | Action |
| --- | --- |
| `534 Application-specific password required` | Generate and enter a Google app password for the sender account. |
| `535 Username and Password not accepted` | Confirm that the Gmail address and app password belong to the same account. Generate a new app password if necessary. |
| Connection timeout | Check internet access and whether the network permits outbound TCP port 465. |
| `550` or `553` | Read the server explanation and check the recipient address or sending restrictions. |
| Message accepted but absent from Inbox | Check Spam, All Mail, the recipient address, and allow time for delivery. |
| Failure during `QUIT` after message acceptance | Check the mailbox before rerunning; the server may already have accepted the email. |

## Submission Checklist

- Include the complete `smtp_client.py` source file.
- Include the screenshot showing the received email.
- Include `Lab3_Reflection_Nisha_Patel.docx`, containing two paragraphs about the experience and challenges, with references.
- Keep this README as supporting documentation.
- Remove the original reflection draft and screenshot placeholder after adding the completed files.
- Confirm that no app password or other credentials are included.
- If ZIP uploads are accepted, compress the completed folder as `Python_Lab3_SMTP_Nisha_Patel_Final.zip` and verify its contents before uploading.

## References

Google. (n.d.). *Sign in with app passwords*. https://support.google.com/mail/answer/185833

Python Software Foundation. (n.d.). *socket — Low-level networking interface*. https://docs.python.org/3/library/socket.html

Google. (n.d.). *IMAP, POP, and SMTP for Gmail*. https://developers.google.com/workspace/gmail/imap/imap-smtp
