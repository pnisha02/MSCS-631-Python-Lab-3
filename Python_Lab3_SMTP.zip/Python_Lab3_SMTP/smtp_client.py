"""SMTP lab: raw sockets and TLS, without smtplib. Run with Python 3."""
import base64
import getpass
import socket
import ssl
from email.utils import formatdate, make_msgid


def read_reply(reader, expected):
    """Read complete SMTP replies, including multiline EHLO responses."""
    reply_code = None
    while True:
        raw = reader.readline(8193)
        if not raw or len(raw) > 8192:
            raise RuntimeError("Connection closed or invalid SMTP reply.")
        line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
        print("S:", line)
        if len(line) < 4 or not line[:3].isdigit() or line[3] not in " -":
            raise RuntimeError("Malformed SMTP reply.")
        code = int(line[:3])
        if reply_code is None:
            reply_code = code
        if code != reply_code:
            raise RuntimeError("Inconsistent multiline SMTP reply.")
        if line[3] == " ":
            break
    if code not in expected:
        raise RuntimeError(f"Expected {expected}, received {code}.")
    return code


def command(sock, reader, text, expected, secret=False):
    print("C:", "[authentication data hidden]" if secret else text)
    sock.sendall((text + "\r\n").encode("ascii"))
    return read_reply(reader, expected)


def address(prompt):
    value = input(prompt).strip()
    if (not value or "@" not in value or
            any(c.isspace() or c in "<>" for c in value)):
        raise ValueError("Enter a plain email address without spaces or brackets.")
    value.encode("ascii")
    return value


def main():
    mailserver = "smtp.gmail.com"
    port = 465
    sender = address("Your Gmail address: ")
    recipient = address("Recipient email address: ")
    password = getpass.getpass("Gmail app password (hidden): ").replace(" ", "")
    if not password:
        raise ValueError("An app password is required.")
    context = ssl.create_default_context()
    # Create a TCP socket and protect it with certificate-verified TLS.
    with socket.create_connection((mailserver, port), timeout=30) as tcp:
        with context.wrap_socket(tcp, server_hostname=mailserver) as clientSocket:
            with clientSocket.makefile("rb") as reader:
                read_reply(reader, (220,))
                # EHLO is the extended form of the skeleton's HELO.
                command(clientSocket, reader, "EHLO localhost", (250,))
                command(clientSocket, reader, "AUTH LOGIN", (334,))
                username = base64.b64encode(sender.encode()).decode("ascii")
                secret = base64.b64encode(password.encode()).decode("ascii")
                command(clientSocket, reader, username, (334,), secret=True)
                command(clientSocket, reader, secret, (235,), secret=True)
                # Send MAIL FROM and print the response.
                command(clientSocket, reader, f"MAIL FROM:<{sender}>", (250,))
                # Send RCPT TO and print the response.
                command(clientSocket, reader, f"RCPT TO:<{recipient}>", (250, 251))
                # Send DATA and wait for permission to transmit the message.
                command(clientSocket, reader, "DATA", (354,))
                headers = [
                    f"From: {sender}", f"To: {recipient}",
                    "Subject: Python Lab 3 SMTP Test - Nisha Patel",
                    f"Date: {formatdate(localtime=True)}",
                    f"Message-ID: {make_msgid()}",
                    "MIME-Version: 1.0",
                    "Content-Type: text/plain; charset=us-ascii",
                ]
                msg = ("I love computer networks!\r\n\r\n"
                       "This email was sent using my Python socket-based SMTP "
                       "client for Python Lab 3.\r\n")
                # Dot-stuff lines before adding the SMTP end-of-data marker.
                data = "\r\n".join(headers) + "\r\n\r\n" + msg
                data = "\r\n".join(
                    "." + line if line.startswith(".") else line
                    for line in data.split("\r\n")
                )
                print("C: [message headers and body]")
                clientSocket.sendall(data.encode("ascii"))
                print("C: .")
                clientSocket.sendall(b".\r\n")  # data already ends in CRLF
                read_reply(reader, (250,))
                print("Server accepted the message. Check the recipient inbox and spam.")
                command(clientSocket, reader, "QUIT", (221,))


if __name__ == "__main__":
    try:
        main()
    except (OSError, ValueError, RuntimeError) as error:
        print(f"SMTP client stopped: {error}")
        raise SystemExit(1)
